<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200">
            Employees
        </h2>
     <?php $__env->endSlot(); ?>
<form method="GET"
      class="mt-4 mb-2 flex flex-col md:flex-row md:items-center md:justify-between gap-3">

    
    <div class="w-full md:w-1/3 md:ml-6">
        <input
            type="text"
            name="search"
            value="<?php echo e(request('search')); ?>"
            placeholder="Search name or email..."
            class="w-full border-gray-300 rounded-md shadow-sm text-sm py-2"
        >
    </div>

    
    <div class="flex items-center gap-2">

        
        <select name="department"
                class="border-gray-300 rounded-md shadow-sm text-sm py-2">
            <option value="">All Departments</option>
            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($department->id); ?>"
                    <?php echo e(request('department') == $department->id ? 'selected' : ''); ?>>
                    <?php echo e($department->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        
        <select name="rank"
                class="border-gray-300 rounded-md shadow-sm text-sm py-2">
            <option value="">All Ranks</option>
            <option value="employee" <?php echo e(request('rank') === 'employee' ? 'selected' : ''); ?>>
                Employee
            </option>
            <option value="head" <?php echo e(request('rank') === 'head' ? 'selected' : ''); ?>>
                Head
            </option>
        </select>

        
        <button type="submit"
                name="sort"
                value="<?php echo e(request('sort') === 'asc' ? 'desc' : 'asc'); ?>"
                class="border border-gray-300 rounded-md px-3 py-2 text-sm hover:bg-gray-100">
            <?php echo e(request('sort') === 'asc' ? 'Z–A' : 'A–Z'); ?>

        </button>

        
        <button type="submit"
                class="bg-indigo-600 text-white px-3 py-2 rounded-md text-sm hover:bg-indigo-700">
            Apply
        </button>
    </div>
</form>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <div class="bg-white dark:bg-gray-800 shadow rounded-lg p-6">

                
                <?php if(session('success')): ?>
                    <div class="mb-4 p-3 text-sm text-green-700 bg-green-100 rounded">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-lg font-medium text-gray-700 dark:text-gray-200">
                        Employee List
                    </h3>

                    <a href="<?php echo e(route('employees.create')); ?>"
                       class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded">
                        + Add Employee
                    </a>
                </div>

                
                <div class="overflow-x-auto mt-0">
                    <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                        <thead class="bg-gray-50 dark:bg-gray-700">
                            <tr>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                    Name
                                </th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                    Email
                                </th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                    Department
                                </th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                    Rank
                                </th>
                                <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                                    Actions
                                </th>
                            </tr>

                        </thead>

                        <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                            <?php $__empty_1 = true; $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="px-4 py-3">
                                        <?php echo e($employee->user->name); ?>

                                    </td>

                                    <td class="px-4 py-3">
                                        <?php echo e($employee->user->email); ?>

                                    </td>

                                    <td class="px-4 py-3">
                                        <?php echo e($employee->department->name ?? '—'); ?>

                                    </td>

                                    <td class="px-4 py-3">
                                        <?php if($employee->rank === 'head'): ?>
                                            <span class="px-2 py-1 text-xs font-semibold text-purple-700 bg-purple-100 rounded">
                                                Head
                                            </span>
                                        <?php else: ?>
                                            <span class="px-2 py-1 text-xs font-semibold text-blue-700 bg-blue-100 rounded">
                                                Employee
                                            </span>
                                        <?php endif; ?>
                                    </td>

                                <td class="px-4 py-3 text-right space-x-3">
                                    <a href="<?php echo e(route('employees.edit', $employee)); ?>" class="text-indigo-600 hover:underline">
                                        Edit
                                    </a>

                                    <form action="<?php echo e(route('employees.destroy', $employee)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button onclick="return confirm('Delete this employee?')" class="text-red-600 hover:underline">
                                            Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4" class="px-4 py-6 text-center text-gray-500">
                                        No employees found.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="mt-4">
                    <?php echo e($employees->links()); ?>

                </div>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\HR_Management\HR-Management-System\hr-system\resources\views/employees/index.blade.php ENDPATH**/ ?>