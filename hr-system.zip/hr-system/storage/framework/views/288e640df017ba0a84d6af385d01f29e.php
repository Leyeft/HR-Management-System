<div class="bg-white dark:bg-gray-800 shadow rounded-lg p-6">

    
    <div>
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
            Department Name
        </label>
        <input
            type="text"
            name="name"
            class="w-full mt-1 border-gray-300 rounded-md shadow-sm
                   focus:ring-indigo-500 focus:border-indigo-500
                   dark:bg-gray-900 dark:border-gray-700 dark:text-gray-200"
            value="<?php echo e(old('name', $department->name ?? '')); ?>"
            required
        >
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="mt-4">
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
            Description (Optional)
        </label>
        <textarea
            name="description"
            rows="3"
            class="w-full mt-1 border-gray-300 rounded-md shadow-sm
                   focus:ring-indigo-500 focus:border-indigo-500
                   dark:bg-gray-900 dark:border-gray-700 dark:text-gray-200"
        ><?php echo e(old('description', $department->description ?? '')); ?></textarea>
        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

</div>
<?php /**PATH C:\laragon\www\HR_Management\HR-Management-System\hr-system\resources\views/departments/_form.blade.php ENDPATH**/ ?>