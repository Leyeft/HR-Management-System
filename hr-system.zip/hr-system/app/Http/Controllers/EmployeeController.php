<?php

namespace App\Http\Controllers;


use App\Models\User;
use App\Models\Employee;
use App\Models\Department;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class EmployeeController extends Controller
{
    //
    public function create()
{
    $departments = Department::all();
    return view('employees.create', compact('departments'));
}

public function store(Request $request)
{
    $request->validate([
        'name' => 'required|string',
        'email' => 'required|email|unique:users',
        'password' => 'required|min:6',
        'department_id' => 'required|exists:departments,id',
        'rank' => 'required|in:employee,head',
        'date_of_birth' => 'required|date',
    ]);

    $user = User::create([
        'name' => $request->name,
        'email' => $request->email,
        'password' => Hash::make($request->password),
        'role' => 'employee',
    ]);

    Employee::create([
        'user_id' => $user->id,
        'department_id' => $request->department_id,
        'rank' => $request->rank,
        'date_of_birth' => $request->date_of_birth,
    ]);

    return redirect()->route('employees.index')->with('success', 'Employee created');
}
public function index()
{
    $employees = Employee::with(['user', 'department'])->get();
    return view('employees.index', compact('employees'));
}


}
