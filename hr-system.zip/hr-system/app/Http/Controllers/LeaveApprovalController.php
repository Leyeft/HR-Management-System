<?php

namespace App\Http\Controllers;

use App\Models\LeaveRequest;
use Illuminate\Http\Request;

class LeaveApprovalController extends Controller
{
    /* =======================
     * INDEX (Head only)
     * ======================= */
    public function index()
    {
        $user = auth()->user();
        $employee = $user->employee;

        // 🔐 Safety check
        if ($employee->rank !== 'head') {
            abort(403);
        }

        $leaves = LeaveRequest::where('department_id', $employee->department_id)
            ->where('status', 'pending')
            ->with('employee.user')
            ->latest()
            ->paginate(10);

        return view('leave.approvals.index', compact('leaves'));
    }

    /* =======================
     * APPROVE
     * ======================= */
    public function approve(LeaveRequest $leave)
    {
        $leave->update([
            'status' => 'approved',
            'rejection_reason' => null,
        ]);

        return back()->with('success', 'Leave approved');
    }

    /* =======================
     * REJECT
     * ======================= */
    public function reject(Request $request, LeaveRequest $leave)
    {
        $request->validate([
            'rejection_reason' => 'required|string|max:255',
        ]);

        $leave->update([
            'status' => 'rejected',
            'rejection_reason' => $request->rejection_reason,
        ]);

        return back()->with('success', 'Leave rejected');
    }
}
