<x-app-layout>
    <div class="max-w-6xl mx-auto py-10">
        <h1 class="text-2xl font-bold mb-6">Employees</h1>

        <table class="w-full border">
            <thead class="bg-gray-100">
                <tr>
                    <th class="border p-2">Name</th>
                    <th class="border p-2">Email</th>
                    <th class="border p-2">Department</th>
                    <th class="border p-2">Rank</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($employees as $employee)
                    <tr>
                        <td class="border p-2">{{ $employee->user->name }}</td>
                        <td class="border p-2">{{ $employee->user->email }}</td>
                        <td class="border p-2">{{ $employee->department->name }}</td>
                        <td class="border p-2 capitalize">{{ $employee->rank_label }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</x-app-layout>
